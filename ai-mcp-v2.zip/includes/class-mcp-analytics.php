<?php
/**
 * AI MCP - Analytics
 *
 * Tracks which AI agents are hitting the MCP endpoints, which endpoints
 * are most queried, and logs referrer bot signatures.
 *
 * Storage: lightweight WordPress options (no extra DB tables).
 * A rolling window of MAX_ENTRIES is kept; oldest entries drop off
 * automatically so the options table never grows unbounded.
 *
 * @package AI_MCP
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AI_MCP_Analytics {

    /** Option key where the log is stored. */
    const LOG_OPTION = 'ai_mcp_access_log';

    /** Daily stats option (aggregated counters). */
    const DAILY_OPTION = 'ai_mcp_daily_stats';

    /** Maximum raw log entries to retain. */
    const MAX_ENTRIES = 2000;

    /**
     * Known AI crawler / assistant signatures.
     * Format: 'Display Name' => ['substring', ...]
     */
    const AI_SIGNATURES = array(
        'Claude'          => array( 'claudebot', 'claude-web', 'anthropic' ),
        'ChatGPT'         => array( 'chatgpt-user', 'oai-searchbot', 'openai' ),
        'Perplexity'      => array( 'perplexitybot', 'perplexity' ),
        'Gemini'          => array( 'google-extended', 'bard', 'gemini' ),
        'Copilot/Bing'    => array( 'bingbot', 'msnbot', 'bingpreview' ),
        'You.com'         => array( 'youbot' ),
        'Cohere'          => array( 'cohere-ai' ),
        'Meta AI'         => array( 'facebookexternalhit', 'meta-ai' ),
        'Mistral'         => array( 'mistral' ),
        'Grok'            => array( 'grok' ),
        'Common Crawl'    => array( 'ccbot' ),
        'GPTBot'          => array( 'gptbot' ),
        'DuckAssist'      => array( 'duckassistbot' ),
    );

    /**
     * Record a single API hit.
     *
     * @param string $endpoint  e.g. 'all', 'pages', 'chunks/12'
     */
    public function track( $endpoint ) {
        $ua       = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
        $referrer = $this->detect_referrer( $ua );
        $ip_hash  = md5( $this->get_client_ip() ); // hash for privacy

        // --- Raw log ---
        $log   = get_option( self::LOG_OPTION, array() );
        $entry = array(
            'ts'       => time(),
            'endpoint' => sanitize_text_field( $endpoint ),
            'agent'    => $referrer,
            'ua_short' => substr( $ua, 0, 150 ),
            'ip_hash'  => $ip_hash,
        );

        array_unshift( $log, $entry );

        // Trim to max
        if ( count( $log ) > self::MAX_ENTRIES ) {
            $log = array_slice( $log, 0, self::MAX_ENTRIES );
        }
        update_option( self::LOG_OPTION, $log, false );

        // --- Daily aggregated stats ---
        $today   = date( 'Y-m-d' );
        $daily   = get_option( self::DAILY_OPTION, array() );

        // Keep last 90 days
        $daily   = array_filter( $daily, function( $d ) {
            return strtotime( $d ) >= strtotime( '-90 days' );
        }, ARRAY_FILTER_USE_KEY );

        if ( ! isset( $daily[ $today ] ) ) {
            $daily[ $today ] = array( 'total' => 0, 'endpoints' => array(), 'agents' => array() );
        }

        $daily[ $today ]['total']++;
        $daily[ $today ]['endpoints'][ $endpoint ]            = ( $daily[ $today ]['endpoints'][ $endpoint ] ?? 0 ) + 1;
        $daily[ $today ]['agents'][ $referrer ]               = ( $daily[ $today ]['agents'][ $referrer ] ?? 0 ) + 1;

        update_option( self::DAILY_OPTION, $daily, false );
    }

    /**
     * Return aggregated stats for the admin dashboard.
     *
     * @return array
     */
    public function get_stats() {
        $log   = get_option( self::LOG_OPTION, array() );
        $daily = get_option( self::DAILY_OPTION, array() );

        // Aggregate from raw log
        $endpoint_counts = array();
        $agent_counts    = array();

        foreach ( $log as $entry ) {
            $ep  = $entry['endpoint'];
            $ag  = $entry['agent'];
            $endpoint_counts[ $ep ] = ( $endpoint_counts[ $ep ] ?? 0 ) + 1;
            $agent_counts[ $ag ]    = ( $agent_counts[ $ag ] ?? 0 ) + 1;
        }

        arsort( $endpoint_counts );
        arsort( $agent_counts );

        // Last 7 days trend
        $trend = array();
        for ( $i = 6; $i >= 0; $i-- ) {
            $day          = date( 'Y-m-d', strtotime( "-{$i} days" ) );
            $trend[ $day ] = $daily[ $day ]['total'] ?? 0;
        }

        return array(
            'total_requests'   => count( $log ),
            'top_endpoints'    => array_slice( $endpoint_counts, 0, 10, true ),
            'top_agents'       => $agent_counts,
            'last_7_days'      => $trend,
            'recent_hits'      => array_slice( $log, 0, 20 ),
        );
    }

    /**
     * Clear all analytics data.
     */
    public function clear() {
        delete_option( self::LOG_OPTION );
        delete_option( self::DAILY_OPTION );
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /**
     * Detect the AI agent/referrer from User-Agent string.
     *
     * @param string $ua
     * @return string  Human-readable agent name or 'Other'.
     */
    private function detect_referrer( $ua ) {
        if ( empty( $ua ) ) {
            return 'Unknown';
        }
        $ua_lower = strtolower( $ua );
        foreach ( self::AI_SIGNATURES as $name => $patterns ) {
            foreach ( $patterns as $pattern ) {
                if ( strpos( $ua_lower, $pattern ) !== false ) {
                    return $name;
                }
            }
        }
        // Generic browser / unknown tool
        return 'Other';
    }

    /**
     * Get client IP, respecting common proxy headers.
     *
     * @return string
     */
    private function get_client_ip() {
        $headers = array(
            'HTTP_CF_CONNECTING_IP',     // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        );
        foreach ( $headers as $header ) {
            if ( ! empty( $_SERVER[ $header ] ) ) {
                // X-Forwarded-For can be a comma-separated list
                $ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) ) )[0] );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }
}
