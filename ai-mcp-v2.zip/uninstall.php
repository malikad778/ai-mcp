<?php
/**
 * Uninstall AI MCP Plugin
 *
 * Fired when the plugin is uninstalled.
 * Cleans up all plugin data, options, and cached files.
 *
 * @package AI_MCP
 */

// If uninstall not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

/**
 * Delete all plugin options
 */
delete_option( 'AI_MCP_last_generated' );
delete_option( 'AI_MCP_needs_regen' );

/**
 * Delete all cached JSON files
 */
$upload_dir = wp_upload_dir();
$json_dir   = wp_normalize_path( $upload_dir['basedir'] . '/ai-mcp/' );

if ( file_exists( $json_dir ) && is_dir( $json_dir ) ) {
    $files = glob( $json_dir . '*.json' );
    
    if ( $files ) {
        foreach ( $files as $file ) {
            if ( is_file( $file ) ) {
                unlink( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
            }
        }
    }
    
    if ( file_exists( $json_dir . 'index.php' ) ) {
        unlink( $json_dir . 'index.php' );
    }

    // Remove the directory
    rmdir( $json_dir );
}

/**
 * Flush rewrite rules to clean up /.well-known/mcp.json
 */
flush_rewrite_rules();

/**
 * Optional: Remove any transients created by the plugin
 * (Currently none, but good practice to include)
 */
// delete_transient( 'ai_mcp_some_transient' );

/**
 * Optional: Clean up any custom database tables
 * (Currently none, but included for future use)
 */
// global $wpdb;
// $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}ai_mcp_custom_table" );
